import os

APP_PORT = os.getenv('APP_PORT', 8088)
